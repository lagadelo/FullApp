| directory document vertices perception view image target |
directory := 'terrain-valence' asFileReference.
document := STONJSON fromString: ('exemple-valence.geojson' asFileReference) contents.
vertices := (document at: 'coordinates') first collect: [ :pair | pair first @ pair second ].
perception := PerceptionAdapter fromDirectory: directory.
perception recordAt: 0 polygon: vertices drones: {
    PerceptionDronePose id: #D01 position: 4.8846@44.9376 heightAboveGround: 200.
    PerceptionDronePose id: #D02 position: 4.8894@44.9376 heightAboveGround: 125 }.
perception recordAfter: 137.5 polygon: vertices drones: {
    PerceptionDronePose id: #D01 position: 4.8898@44.9391 heightAboveGround: 200.
    PerceptionDronePose id: #D02 position: 4.8924@44.9395 heightAboveGround: 125 }.
view := PerceptionRoassalView on: perception.
image := view asForm.
target := directory / 'exemple.png'.
target ensureDelete.
PNGReadWriter putForm: image onFileNamed: target fullName.
