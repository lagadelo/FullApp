Object subclass: #PerceptionCoordinateTransform
    instanceVariableNames: ''
    classVariableNames: ''
    package: 'CouplagePerceptionRoassal'!

Object subclass: #PerceptionTerrain
    instanceVariableNames: 'crs origin cellSize columns rows ground surface minimumSurface maximumSurface'
    classVariableNames: ''
    package: 'CouplagePerceptionRoassal'!

Object subclass: #PerceptionDronePose
    instanceVariableNames: 'identifier position altitude heightAboveGround'
    classVariableNames: ''
    package: 'CouplagePerceptionRoassal'!

Object subclass: #PerceptionAdapter
    instanceVariableNames: 'terrain referenceTerrain gridOffset projection fadeSeconds sensorPixels halfField time polygon poses observations intervalOverlaps omissions footprintClipped'
    classVariableNames: ''
    package: 'CouplagePerceptionRoassal'!

Object subclass: #PerceptionRoassalView
    instanceVariableNames: 'adapter canvas background backgroundTerrain mapOrigin mapScale colors'
    classVariableNames: ''
    package: 'CouplagePerceptionRoassal'!

!PerceptionTerrain class methodsFor: 'import'!
fromDirectory: aDirectory
    | directory metadata |
    directory := aDirectory asFileReference.
    metadata := STONJSON fromString: (directory / 'terrain.json') contents.
    ^ self fromDirectory: directory metadata: metadata
!

fromDirectory: directory metadata: metadata
    | surfaceFile model |
    (metadata at: 'version') = 1 ifFalse: [ self error: 'Version de terrain.json incompatible.' ].
    surfaceFile := metadata at: 'surface' ifAbsent: [ nil ].
    model := self
        fromCsv: directory / (metadata at: 'ground')
        surfaceCsv: (surfaceFile ifNotNil: [ directory / surfaceFile ])
        origin: ((metadata at: 'topLeft') first @ (metadata at: 'topLeft') second)
        cellSize: ((metadata at: 'cellSize') first @ (metadata at: 'cellSize') second)
        crs: (metadata at: 'crs')
        noData: (metadata at: 'noData').
    ((metadata at: 'columns') = model columns and: [ (metadata at: 'rows') = model rows ])
        ifFalse: [ self error: 'Les dimensions annoncées diffèrent du CSV.' ].
    ^ model
!

fromCsv: groundCsv surfaceCsv: surfaceCsv origin: topLeft cellSize: spacing crs: crsName noData: sentinel
    | groundRows surfaceRows |
    groundRows := self readCsv: groundCsv asFileReference noData: sentinel.
    surfaceRows := surfaceCsv ifNotNil: [ self readCsv: surfaceCsv asFileReference noData: sentinel ].
    ^ self new initializeGround: groundRows surface: surfaceRows origin: topLeft cellSize: spacing crs: crsName
!

readCsv: csv noData: sentinel
    | lines width |
    lines := OrderedCollection new.
    width := nil.
    csv readStreamDo: [ :stream |
        [ stream atEnd ] whileFalse: [
            | fields |
            fields := stream nextLine splitOn: $,.
            width ifNil: [ width := fields size ].
            (width > 0 and: [ fields size = width ]) ifFalse: [
                self error: 'Le CSV doit être rectangulaire (ligne ', (lines size + 1) printString, ').' ].
            lines add: (fields collect: [ :field |
                | numeric textStream value |
                numeric := field trimmed.
                numeric isEmpty
                    ifTrue: [ nil ]
                    ifFalse: [
                        textStream := numeric readStream.
                        value := Number readFrom: textStream.
                        (textStream atEnd and: [ value asFloat isFinite ])
                            ifFalse: [ self error: 'Altitude CSV invalide (ligne ', (lines size + 1) printString, ').' ].
                        value = sentinel ifTrue: [ nil ] ifFalse: [ value asFloat ] ] ]) ] ].
    lines isEmpty ifTrue: [ self error: 'Le CSV du terrain est vide.' ].
    ^ lines
! !

!PerceptionTerrain methodsFor: 'configuration'!
initializeGround: bareEarth surface: topSurface origin: topLeft cellSize: spacing crs: crsName
    | valid |
    (spacing x > 0 and: [ spacing y > 0 ]) ifFalse: [ self error: 'Le pas de grille doit être positif.' ].
    origin := topLeft x asFloat @ topLeft y asFloat.
    cellSize := spacing x asFloat @ spacing y asFloat.
    crs := crsName asString.
    rows := bareEarth size.
    columns := bareEarth first size.
    ground := bareEarth flatCollect: [ :row | row ] as: Array.
    topSurface
        ifNil: [ surface := ground ]
        ifNotNil: [
            (topSurface size = rows and: [ topSurface first size = columns ]) ifFalse: [
                self error: 'Le MNT et le MNS doivent utiliser la même grille.' ].
            surface := topSurface flatCollect: [ :row | row ] as: Array.
            1 to: surface size do: [ :i |
                | base roof |
                base := ground at: i.
                roof := surface at: i.
                (base notNil and: [ roof notNil ]) ifTrue: [ surface at: i put: (base max: roof) ] ] ].
    valid := surface reject: #isNil.
    valid isEmpty ifTrue: [ self error: 'Aucune altitude exploitable dans la grille.' ].
    minimumSurface := valid min.
    maximumSurface := valid max
! !

!PerceptionTerrain methodsFor: 'georeferencing'!
gridCoordinatesOf: worldPoint
    ^ ((worldPoint x - origin x) / cellSize x) @ ((origin y - worldPoint y) / cellSize y)
!

projectedCenterAtColumn: column row: row
    ^ (origin x + ((column + 0.5) * cellSize x)) @ (origin y - ((row + 0.5) * cellSize y))
!

projectedBounds
    ^ (origin x @ (origin y - (rows * cellSize y))) corner: ((origin x + (columns * cellSize x)) @ origin y)
!

includesGrid: gridPoint
    ^ gridPoint x >= 0 and: [ gridPoint x < columns and: [ gridPoint y >= 0 and: [ gridPoint y < rows ] ] ]
!

includesProjectedPoint: point
    ^ self includesGrid: (self gridCoordinatesOf: point)
!

offsetFrom: reference
    | offset integerOffset |
    (crs = reference crs and: [ cellSize = reference cellSize ]) ifFalse: [
        self error: 'Pour conserver la mémoire, garder le même CRS et le même pas.' ].
    offset := reference gridCoordinatesOf: origin.
    integerOffset := offset x rounded @ offset y rounded.
    ((offset x - integerOffset x) abs < 0.000001 and: [ (offset y - integerOffset y) abs < 0.000001 ])
        ifFalse: [ self error: 'La nouvelle grille doit être alignée sur les cellules de la première.' ].
    ^ integerOffset
! !

!PerceptionTerrain methodsFor: 'accessing'!
columns
    ^ columns
!

rows
    ^ rows
!

origin
    ^ origin
!

cellSize
    ^ cellSize
!

crs
    ^ crs
!

minimumSurface
    ^ minimumSurface
!

maximumSurface
    ^ maximumSurface
!

groundAt: projectedPoint
    | grid |
    grid := self gridCoordinatesOf: projectedPoint.
    (self includesGrid: grid) ifFalse: [ ^ nil ].
    ^ self groundAtColumn: grid x floor row: grid y floor
!

groundAtColumn: column row: row
    ^ ground at: row * columns + column + 1
!

surfaceAtColumn: column row: row
    ^ surface at: row * columns + column + 1
! !

!PerceptionTerrain methodsFor: 'visibility'!
visibleColumn: column row: row from: cameraGrid elevation: cameraAltitude clearance: clearance
    "The ray rises from the target centre. A crossed cell is tested at the ray's lowest point within it."
    | x y sensorX sensorY dx dy stepX stepY deltaX deltaY nextX nextY entryX entryY t surfaceZ targetZ |
    x := column.
    y := row.
    sensorX := cameraGrid x floor.
    sensorY := cameraGrid y floor.
    dx := cameraGrid x - (x + 0.5).
    dy := cameraGrid y - (y + 0.5).
    stepX := dx sign.
    stepY := dy sign.
    deltaX := stepX = 0 ifTrue: [ Float infinity ] ifFalse: [ 1.0 / dx abs ].
    deltaY := stepY = 0 ifTrue: [ Float infinity ] ifFalse: [ 1.0 / dy abs ].
    nextX := deltaX / 2.
    nextY := deltaY / 2.
    targetZ := cameraAltitude - clearance.
    [ x = sensorX and: [ y = sensorY ] ] whileFalse: [
        entryX := x = sensorX ifTrue: [ Float infinity ] ifFalse: [ nextX ].
        entryY := y = sensorY ifTrue: [ Float infinity ] ifFalse: [ nextY ].
        t := entryX min: entryY.
        entryX <= t ifTrue: [ x := x + stepX. nextX := nextX + deltaX ].
        entryY <= t ifTrue: [ y := y + stepY. nextY := nextY + deltaY ].
        surfaceZ := self surfaceAtColumn: x row: y.
        (surfaceZ isNil or: [ surfaceZ > (targetZ + (clearance * t) + 0.000001) ]) ifTrue: [ ^ false ] ].
    ^ true
! !

!PerceptionDronePose class methodsFor: 'instance creation'!
id: id position: point heightAboveGround: meters
    meters > 0 ifFalse: [ self error: 'La hauteur au-dessus du sol doit être positive.' ].
    ^ self new initializeId: id position: point altitude: meters aboveGround: true
!

id: id position: point elevation: meters
    ^ self new initializeId: id position: point altitude: meters aboveGround: false
! !

!PerceptionDronePose methodsFor: 'accessing'!
initializeId: id position: point altitude: meters aboveGround: useAgl
    (id notNil and: [ point isPoint and: [ meters isNumber and: [ meters asFloat isFinite ] ] ])
        ifFalse: [ self error: 'Identifiant, position ou altitude de drone invalide.' ].
    identifier := id.
    position := point x @ point y.
    altitude := meters asFloat.
    heightAboveGround := useAgl
!

id
    ^ identifier
!

position
    ^ position
!

altitude
    ^ altitude
!

usesHeightAboveGround
    ^ heightAboveGround
!

withPosition: projectedPoint
    ^ self class new initializeId: identifier position: projectedPoint altitude: altitude aboveGround: heightAboveGround
! !

!PerceptionAdapter class methodsFor: 'instance creation'!
fromDirectory: aDirectory
    | directory metadata |
    directory := aDirectory asFileReference.
    metadata := STONJSON fromString: (directory / 'terrain.json') contents.
    ^ self on: (PerceptionTerrain fromDirectory: directory metadata: metadata)
        projection: (PerceptionCoordinateTransform forMetadata: metadata)
!

on: terrain
    ^ self on: terrain projection: [ :point | point ]
!

on: terrain projection: transform
    ^ self new initializeOn: terrain projection: transform
! !

!PerceptionAdapter methodsFor: 'setup'!
initializeOn: aTerrain projection: transform
    referenceTerrain := aTerrain.
    projection := transform.
    observations := Dictionary new.
    polygon := #().
    poses := #().
    omissions := Dictionary new.
    intervalOverlaps := 0.
    footprintClipped := false.
    fadeSeconds := 300.
    halfField := 2.5.
    sensorPixels := 2000.
    self replaceTerrain: aTerrain
!

replaceTerrain: aTerrain
    | offset |
    offset := aTerrain offsetFrom: referenceTerrain.
    terrain := aTerrain.
    gridOffset := offset
!

fadeAfterSeconds: seconds
    (seconds > 0 and: [ seconds asFloat isFinite ]) ifFalse: [ self error: 'Durée de fraîcheur invalide.' ].
    fadeSeconds := seconds
!

cameraHalfFieldTangent: tangent sensorSidePixels: pixels
    (tangent > 0 and: [ tangent asFloat isFinite and: [ pixels isInteger and: [ pixels > 0 ] ] ])
        ifFalse: [ self error: 'Paramètres de caméra invalides.' ].
    halfField := tangent asFloat.
    sensorPixels := pixels
!

projectPoint: localPoint
    | projected |
    projected := projection value: localPoint.
    (projected isPoint and: [ projected x isNumber and: [ projected y isNumber and: [
        projected x asFloat isFinite and: [ projected y asFloat isFinite ] ] ] ])
        ifFalse: [ self error: 'La projection doit retourner un Point en mètres.' ].
    ^ projected x asFloat @ projected y asFloat
!

projectPolygon: vertices
    | projected first area |
    projected := vertices asArray collect: [ :vertex | self projectPoint: vertex ].
    (projected size > 1 and: [ projected first = projected last ]) ifTrue: [
        projected := projected allButLast ].
    projected asSet size < 3 ifTrue: [ self error: 'Le polygone doit avoir au moins trois sommets distincts.' ].
    first := projected first.
    area := 0.0.
    1 to: projected size do: [ :i |
        | a b |
        a := (projected at: i) - first.
        b := (projected at: (i \\ projected size) + 1) - first.
        area := area + (a x * b y) - (a y * b x) ].
    area abs <= 0.000000001 ifTrue: [ self error: 'Le polygone doit délimiter une surface non nulle.' ].
    ^ projected
! !

!PerceptionAdapter methodsFor: 'simulation'!
recordAfter: duration polygon: vertices drones: dronePoses
    (duration isNumber and: [ duration > 0 and: [ duration asFloat isFinite ] ]) ifFalse: [
        self error: 'La durée du pas doit être finie et positive.' ].
    ^ self recordAt: (time ifNil: [ 0 ]) + duration polygon: vertices drones: dronePoses
!

recordAt: seconds polygon: vertices drones: dronePoses
    "Call after the movement and control update of a simulator tick. Time is cumulative simulated seconds."
    | nextPolygon nextPoses nextSeen overlaps nextOmissions nextClipped ids |
    (seconds isNumber and: [ seconds asFloat isFinite and: [ seconds >= 0 and: [ time isNil or: [ seconds > time ] ] ] ])
        ifFalse: [ self error: 'Le temps simulé doit être fini et strictement croissant.' ].
    nextPolygon := self projectPolygon: vertices.
    nextPoses := dronePoses asArray collect: [ :pose | pose withPosition: (self projectPoint: pose position) ].
    ids := nextPoses collect: #id.
    ids asSet size = ids size ifFalse: [ self error: 'Chaque drone doit conserver un identifiant distinct.' ].
    nextSeen := Dictionary new.
    overlaps := Set new.
    nextOmissions := Dictionary new.
    nextClipped := false.
    nextPoses do: [ :pose |
        | result |
        result := self observePose: pose do: [ :cell :gsd |
            | before |
            before := nextSeen at: cell ifAbsent: [ nil ].
            before ifNotNil: [ overlaps add: cell ].
            (before isNil or: [ gsd < before second ]) ifTrue: [
                nextSeen at: cell put: { seconds. gsd. pose id } ] ].
        result = #bord ifTrue: [ nextClipped := true ].
        (#(ok bord) includes: result) ifFalse: [ nextOmissions at: pose id put: result ] ].
    nextSeen keysAndValuesDo: [ :cell :reading | observations at: cell put: reading ].
    time := seconds.
    polygon := nextPolygon.
    poses := nextPoses.
    omissions := nextOmissions.
    intervalOverlaps := overlaps size.
    footprintClipped := nextClipped.
    ^ self
!

observePose: pose do: receiver
    | point cameraGrid elevation groundZ surfaceZ radius spacing lower upper clipped |
    point := pose position.
    cameraGrid := terrain gridCoordinatesOf: point.
    (terrain includesGrid: cameraGrid) ifFalse: [ ^ #horsTerrain ].
    elevation := pose altitude.
    pose usesHeightAboveGround ifTrue: [
        groundZ := terrain groundAt: point.
        groundZ ifNil: [ ^ #solInconnu ].
        elevation := elevation + groundZ ].
    surfaceZ := terrain surfaceAtColumn: cameraGrid x floor row: cameraGrid y floor.
    surfaceZ ifNil: [ ^ #surfaceInconnue ].
    elevation <= surfaceZ ifTrue: [ ^ #sousSurface ].
    spacing := terrain cellSize.
    radius := (elevation - terrain minimumSurface) * halfField.
    lower := cameraGrid - ((radius / spacing x) @ (radius / spacing y)).
    upper := cameraGrid + ((radius / spacing x) @ (radius / spacing y)).
    clipped := lower x < 0 or: [ lower y < 0 or: [ upper x > terrain columns or: [ upper y > terrain rows ] ] ].
    ((lower y floor) max: 0) to: ((upper y ceiling) min: terrain rows - 1) do: [ :row |
        ((lower x floor) max: 0) to: ((upper x ceiling) min: terrain columns - 1) do: [ :column |
            | height offset clearance |
            height := terrain surfaceAtColumn: column row: row.
            height ifNotNil: [
                clearance := elevation - height.
                offset := ((column + 0.5 - cameraGrid x) abs * spacing x)
                    max: ((row + 0.5 - cameraGrid y) abs * spacing y).
                (clearance > 0 and: [ offset <= (halfField * clearance) and: [
                    terrain visibleColumn: column row: row from: cameraGrid elevation: elevation clearance: clearance ] ])
                    ifTrue: [ receiver value: (column @ row) + gridOffset
                        value: 2 * halfField * clearance / sensorPixels ] ] ] ].
    ^ clipped ifTrue: [ #bord ] ifFalse: [ #ok ]
! !

!PerceptionAdapter methodsFor: 'query'!
terrain
    ^ terrain
!

time
    ^ time
!

polygon
    ^ polygon copy
!

poses
    ^ poses copy
!

fadeSeconds
    ^ fadeSeconds
!

omissions
    ^ omissions copy
!

overlapCellCount
    ^ intervalOverlaps
!

footprintMayBeClipped
    ^ footprintClipped
!

polygonIncludedInTerrain
    | bounds |
    bounds := terrain projectedBounds.
    ^ polygon allSatisfy: [ :vertex |
        (vertex x between: bounds origin x and: bounds corner x) and: [
            vertex y between: bounds origin y and: bounds corner y ] ]
!

observationAt: localPoint
    "Answer { simulated time. metres per pixel. drone id }, or nil."
    | cell answer |
    cell := referenceTerrain gridCoordinatesOf: (self projectPoint: localPoint).
    answer := observations at: (cell x floor @ cell y floor) ifAbsent: [ nil ].
    ^ answer ifNotNil: [ answer copy ]
!

visibleGridObservationsDo: block
    observations keysAndValuesDo: [ :globalCell :reading |
        | currentCell |
        currentCell := globalCell - gridOffset.
        (terrain includesGrid: currentCell) ifTrue: [ block value: currentCell value: reading ] ]
!

whitenessOf: reading
    ^ ((time - reading first) / fadeSeconds asFloat) min: 1.0
! !

!PerceptionRoassalView class methodsFor: 'instance creation'!
on: adapter
    ^ self new initializeOn: adapter
! !

!PerceptionRoassalView methodsFor: 'configuration'!
initializeOn: aPerceptionAdapter
    adapter := aPerceptionAdapter.
    canvas := RSCanvas new extent: 860@660; color: (Color fromHexString: '101B29'); yourself.
    colors := #('F7DF79' '71E3AF' '5DD0EB' '6E9CFF' 'BEA9FF') collect: [ :hex | Color fromHexString: hex ]
!

canvas
    ^ canvas
!

open
    self refresh.
    ^ canvas open
!

asForm
    self refresh.
    ^ canvas asForm
! !

!PerceptionRoassalView methodsFor: 'drawing'!
refresh
    | terrain available mapExtent |
    terrain := adapter terrain.
    available := canvas extent - (36@100).
    (available x <= 0 or: [ available y <= 0 ]) ifTrue: [ ^ self ].
    mapScale := (available x / (terrain columns * terrain cellSize x))
        min: (available y / (terrain rows * terrain cellSize y)).
    mapExtent := ((terrain columns * terrain cellSize x) @ (terrain rows * terrain cellSize y)) * mapScale.
    mapOrigin := (((canvas extent x - mapExtent x) / 2) @ 44).
    canvas fixedShapes copy do: #remove.
    self drawBitmap: (self reliefFor: terrain) extent: mapExtent.
    self drawBitmap: (self overlayFor: terrain) extent: mapExtent.
    self drawPolygon.
    self drawDrones.
    self drawLegend.
    canvas signalUpdate
!

reliefFor: terrain
    | low high bright dark invalid |
    backgroundTerrain == terrain ifTrue: [ ^ background ].
    low := terrain minimumSurface.
    high := terrain maximumSurface max: low + 20.
    bright := Color fromHexString: '65788B'.
    dark := Color fromHexString: '263B50'.
    invalid := Color fromHexString: '0B141F'.
    background := Form extent: terrain columns @ terrain rows depth: 32.
    0 to: terrain rows - 1 do: [ :row |
        0 to: terrain columns - 1 do: [ :column |
            | z fraction shade |
            z := terrain surfaceAtColumn: column row: row.
            shade := z ifNil: [ invalid ] ifNotNil: [
                fraction := (z - low) / (high - low).
                bright mixed: fraction with: dark ].
            background colorAt: column@row put: shade ] ].
    backgroundTerrain := terrain.
    ^ background
!

overlayFor: terrain
    | overlay white limits |
    overlay := Form extent: terrain columns @ terrain rows depth: 32.
    white := Color fromHexString: 'F8FBFF'.
    limits := #(0.15 0.30 0.45 0.65).
    adapter visibleGridObservationsDo: [ :cell :reading |
        | shade grade |
        grade := limits findFirst: [ :limit | reading second <= limit ].
        shade := (colors at: (grade = 0 ifTrue: [ 5 ] ifFalse: [ grade ]))
            mixed: 1 - (adapter whitenessOf: reading) with: white.
        overlay colorAt: cell put: (shade alpha: 0.74) ].
    ^ overlay
!

drawPolygon
    | vertices color |
    vertices := adapter polygon.
    color := Color fromHexString: 'F5DD86'.
    1 to: vertices size do: [ :i |
        | shape |
        shape := RSLine new
            startPoint: (self screenPoint: (vertices at: i));
            endPoint: (self screenPoint: (vertices at: (i \\ vertices size) + 1));
            color: color;
            width: 1.6;
            dashArray: #(6 4);
            yourself.
        self addFixed: shape ]
!

drawDrones
    adapter poses do: [ :pose |
        | point shape |
        (adapter terrain includesProjectedPoint: pose position) ifTrue: [
            point := self screenPoint: pose position.
            shape := RSEllipse new size: 9; color: Color white; yourself.
            shape translateTo: point.
            self addFixed: shape.
            self label: pose id asString at: point + (6 @ -17) size: 12 color: Color white ] ]
!

drawLegend
    | title y labels muted |
    muted := Color fromHexString: 'C0CEE0'.
    title := adapter time ifNil: [ 'En attente du premier pas' ] ifNotNil: [ :seconds |
        'Temps simulé  ', ((seconds printShowingDecimalPlaces: 2) copyReplaceAll: '.' with: ','), ' s' ].
    self label: title at: 16@10 size: 18 color: Color white.
    (adapter polygonIncludedInTerrain not or: [ adapter footprintMayBeClipped ]) ifTrue: [
        self label: 'Bord du modèle de terrain' at: (canvas extent x - 211)@14
            size: 13 color: (Color fromHexString: 'F5DD86') ].
    y := canvas extent y - 49.
    self label: 'Finesse (m/px)' at: 16@y size: 13 color: muted.
    labels := #('≤ 0,15' '≤ 0,30' '≤ 0,45' '≤ 0,65' '> 0,65').
    labels doWithIndex: [ :text :index |
        self label: text at: (139 + ((index - 1) * 63))@y size: 13 color: (colors at: index) ].
    self label: ('Blanc après ', adapter fadeSeconds printString, ' s sans passage')
        at: 16@(y + 21) size: 13 color: muted
!

screenPoint: projectedPoint
    | grid spacing |
    grid := adapter terrain gridCoordinatesOf: projectedPoint.
    spacing := adapter terrain cellSize.
    ^ mapOrigin + (((grid x * spacing x) @ (grid y * spacing y)) * mapScale)
!

drawBitmap: form extent: dimensions
    | shape |
    shape := RSBitmap new form: form; extent: dimensions; yourself.
    shape translateTo: mapOrigin + (dimensions / 2).
    self addFixed: shape
!

label: text at: point size: size color: color
    | label |
    label := RSLabel new text: text; fontSize: size; color: color; yourself.
    label translateTo: point + (label extent / 2).
    self addFixed: label
!

addFixed: shape
    shape setAsFixed.
    canvas add: shape
! !

!PerceptionCoordinateTransform class methodsFor: 'projection'!
forMetadata: metadata
    | input output origin direction converter |
    output := metadata at: 'crs'.
    input := metadata at: 'inputCrs' ifAbsent: [ output ].
    origin := (metadata at: 'inputOrigin' ifAbsent: [ nil ])
        ifNil: [ 0@0 ] ifNotNil: [ :coords | coords first @ coords second ].
    direction := (metadata at: 'inputYDown' ifAbsent: [ false ]) ifTrue: [ -1 ] ifFalse: [ 1 ].
    converter := self from: input to: output.
    ^ [ :point | converter value: origin + (point x @ (point y * direction)) ]
!

from: input to: output
    | code |
    input = output ifTrue: [ ^ [ :point | point ] ].
    (#('EPSG:4326' 'OGC:CRS84') includes: input) ifFalse: [
        self error: 'Pour ce changement de CRS, fournir le bloc de projection à PerceptionAdapter on:projection:.' ].
    output = 'EPSG:2154' ifTrue: [ ^ [ :point | self lambert93: point ] ].
    code := (output copyAfter: $:) asInteger.
    (code between: 32601 and: 32660) ifTrue: [
        ^ [ :point | self utm: point zone: code - 32600 falseNorthing: 0.0 ] ].
    (code between: 32701 and: 32760) ifTrue: [
        ^ [ :point | self utm: point zone: code - 32700 falseNorthing: 10000000.0 ] ].
    self error: 'Pour ce CRS de grille, fournir le bloc de projection à PerceptionAdapter on:projection:.'
!

lambert93: lonLat
    "Lambert conformal conic 2SP, IGN constants for the RGF93 / Lambert-93 conversion."
    | latitude longitude e eSin isometric radius convergence |
    latitude := lonLat y * Float pi / 180.
    longitude := (lonLat x - 3) * Float pi / 180.
    e := 0.0818191910428158.
    eSin := e * latitude sin.
    isometric := ((Float pi / 4 + (latitude / 2)) tan) ln
        - ((e / 2) * ((1 + eSin) / (1 - eSin)) ln).
    radius := 11754255.426096 * ((0.7256077650532671 * isometric) negated exp).
    convergence := 0.7256077650532671 * longitude.
    ^ (700000 + (radius * convergence sin)) @ (12655612.049876 - (radius * convergence cos))
!

utm: lonLat zone: zone falseNorthing: offset
    "WGS 84 Transverse Mercator series, used within the UTM zone of the scene."
    | latitude longitude sine cosine tangent e2 e4 e6 secondEccentricity
      normal t c a a2 meridian easting northing |
    latitude := lonLat y * Float pi / 180.
    longitude := (lonLat x - ((6 * zone) - 183)) * Float pi / 180.
    sine := latitude sin.
    cosine := latitude cos.
    tangent := latitude tan.
    e2 := 0.0066943799901413165.
    e4 := e2 squared.
    e6 := e4 * e2.
    secondEccentricity := e2 / (1 - e2).
    normal := 6378137.0 / (1 - (e2 * sine squared)) sqrt.
    t := tangent squared.
    c := secondEccentricity * cosine squared.
    a := longitude * cosine.
    a2 := a squared.
    meridian := 6378137.0 * (
        ((1 - (e2 / 4) - (3 * e4 / 64) - (5 * e6 / 256)) * latitude)
        - (((3 * e2 / 8) + (3 * e4 / 32) + (45 * e6 / 1024)) * (2 * latitude) sin)
        + (((15 * e4 / 256) + (45 * e6 / 1024)) * (4 * latitude) sin)
        - ((35 * e6 / 3072) * (6 * latitude) sin)).
    easting := 500000 + (0.9996 * normal * (a
        + ((1 - t + c) * a * a2 / 6)
        + ((5 - (18 * t) + t squared + (72 * c) - (58 * secondEccentricity)) * a * a2 squared / 120))).
    northing := offset + (0.9996 * (meridian + (normal * tangent * (
        (a2 / 2)
        + ((5 - t + (9 * c) + (4 * c squared)) * a2 squared / 24)
        + ((61 - (58 * t) + t squared + (600 * c) - (330 * secondEccentricity)) * a2 squared * a2 / 720))))).
    ^ easting @ northing
! !
