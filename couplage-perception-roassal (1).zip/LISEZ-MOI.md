# Raccorder le simulateur à Roassal

Ce kit charge le terrain à partir du polygone et observe l’état du simulateur aux instants fournis. Le simulateur calcule le déplacement et les nouvelles vitesses avec sa loi de consensus. L’adaptateur associe à chaque cellule observée la date du relevé et sa résolution estimée.

## 1. Préparer le terrain à partir du polygone

Le seul fichier d’entrée de la préparation automatique est le polygone. `preparer-terrain.py` accepte un `Polygon` GeoJSON, une `Feature` contenant ce polygone ou une liste JSON de sommets ordonnés. Les sommets peuvent décrire un contour concave. En GeoJSON standard ou en liste sans déclaration de CRS, les paires s’écrivent `[longitude, latitude]` en degrés. Le fichier peut aussi déclarer un CRS projeté en mètres, par exemple `"crs": "EPSG:2154"`. Des XY purement locaux nécessitent un rattachement géographique. Pour obtenir la liste JSON depuis des points Pharo en longitude et latitude, utilise `STONJSON toString: (sommets collect: [ :p | { p x. p y } ])`.

```sh
python3 preparer-terrain.py mon-polygone.geojson terrain-mission
```

Le script utilise l’IGN RGE ALTI® en France métropolitaine et USGS 3DEP aux États-Unis contigus. Tu peux aussi utiliser ton propre MNT GeoTIFF avec `--mnt`. Un MNS GeoTIFF optionnel, passé avec `--mns`, permet d’inclure les toits et d’autres obstacles. Les deux rasters sont reprojetés sur la même grille. L’installation du préparateur demande Python avec `numpy`, `osgeo` (GDAL) et `pyproj`. [IGN RGE ALTI®](https://www.data.gouv.fr/datasets/rge-alti-r) · [USGS 3DEP](https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer)

Les dimensions sont calculées à partir de l’emprise du polygone, de la marge et du pas de grille. Les valeurs par défaut sont 700 m de marge et 20 m de pas. `--pas`, `--pas-nord` et `--marge` permettent d’adapter le calcul à la scène. Le fichier `terrain.json` décrit le CRS, le coin nord-ouest, les dimensions, le pas et la valeur NoData. Les CSV ont un nombre libre de lignes et de colonnes, avec des lignes de même longueur. Les altitudes sont exprimées en mètres. La première ligne du CSV est la ligne la plus au nord.

## 2. Enregistrer l’état au temps fourni

Charge `couplage-perception.st` dans Pharo avec Roassal. Après chargement du terrain, les positions restent dans le repère des sommets d’entrée. L’adaptateur convertit automatiquement le GeoJSON WGS 84 vers Lambert-93 ou l’UTM de la grille. Pour un polygone déjà métrique, le préparateur conserve par défaut son CRS. `PerceptionAdapter on:projection:` permet d’utiliser une autre transformation si ton projet en dispose.

```smalltalk
perception := PerceptionAdapter fromDirectory: 'terrain-mission'.
vue := PerceptionRoassalView on: perception.
vue open.
```

À la fin du pas du simulateur, passe le contour courant, les positions et l’instant simulé. Les poses portent un identifiant stable et une altitude, ici une hauteur au-dessus du sol. Si tu as une altitude dans le référentiel vertical du terrain, construis la pose avec `id:position:elevation:`. L’exemple ci-dessous attend `identifiant` et `position` fournis par tes accesseurs.

```smalltalk
instantanes := drones collect: [ :drone |
    PerceptionDronePose
        id: drone identifiant
        position: drone position
        heightAboveGround: 200 ].

perception recordAt: tempsSimule
    polygon: sommetsCourants
    drones: instantanes.
vue refresh.
```

`tempsSimule` est un instant cumulé en secondes. Il peut être fractionnaire et croître d’un montant différent à chaque enregistrement. Si ton simulateur fournit la durée du pas, utilise `recordAfter: dureeDuPas polygon: sommetsCourants drones: instantanes`. La première date cumulée vaut alors la durée fournie. Pour observer l’état initial, appelle `recordAt: 0`.

La dernière observation remplace la précédente. Si plusieurs drones observent une cellule au même instant, l’adaptateur garde la mesure la plus fine. `observationAt:` renvoie `{ instant. mètresParPixel. idDrone }`, ou `nil`. Les cellules blanchissent selon le temps simulé écoulé, avec un délai de 300 s par défaut. Le blanchiment se règle par `fadeAfterSeconds:`. La résolution est estimée pour une caméra verticale et des cellules horizontalement planes. `vue asForm` fournit une image Roassal que tu peux exporter à la cadence de ton choix.

## 3. Faire évoluer le polygone

Passe les nouveaux sommets à chaque enregistrement. Les observations sont liées aux cellules du terrain et continuent de vieillir au fil des changements de contour. Si le contour ou les empreintes atteignent le bord du terrain, la vue le signale. `polygonIncludedInTerrain`, `footprintMayBeClipped` et `omissions` permettent aussi de lire ces états côté simulateur.

Pour agrandir la scène, prépare une grille étendue alignée sur la première puis charge-la dans l’adaptateur courant.

```sh
python3 preparer-terrain.py nouveau-polygone.geojson terrain-etendu --etendre terrain-mission
```

```smalltalk
perception replaceTerrain: (PerceptionTerrain fromDirectory: 'terrain-etendu').
```

Le chargement garde le temps et la mémoire des cellules déjà observées. Pour une scène située ailleurs que dans les régions couvertes par la recherche automatique, utilise le même GeoTIFF source avec `--mnt` lors de la préparation et de l’extension.

## Essai à Valence

```sh
python3 preparer-terrain.py exemple-valence.geojson terrain-valence --pas 30
./pharo Pharo.image st --quit couplage-perception.st exemple-valence.st
```

L’exemple enregistre deux états espacés de 137,5 s et écrit `terrain-valence/exemple.png`. Le kit a été vérifié avec Pharo 13 et Roassal sous Linux.
