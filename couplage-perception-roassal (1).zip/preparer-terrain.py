#!/usr/bin/env python3
"""Prépare une grille métrique autour d'un polygone pour Pharo et Roassal."""
import argparse
from dataclasses import dataclass
import gzip
import json
import math
from pathlib import Path
import tempfile
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from uuid import uuid4

import numpy as np
from osgeo import gdal, osr
from pyproj import CRS, Transformer

IGN = 'https://data.geopf.fr/wms-r/wms'
USGS = 'https://elevation.nationalmap.gov/arcgis/rest/services/3DEPElevation/ImageServer/exportImage'
NO_DATA = -9999.0
TILE_SIDE = 640

gdal.UseExceptions()
osr.UseExceptions()


@dataclass(frozen=True)
class Grid:
    epsg: int
    origin: tuple
    spacing: tuple
    columns: int
    rows: int

    @property
    def bounds(self):
        x, y = self.origin
        dx, dy = self.spacing
        return (x, y - self.rows * dy, x + self.columns * dx, y)

    def tile(self, x, y):
        dx, dy = self.spacing
        return Grid(self.epsg, (self.origin[0] + x * dx, self.origin[1] - y * dy),
                    self.spacing, min(TILE_SIDE, self.columns - x), min(TILE_SIDE, self.rows - y))


def declared_crs(document):
    if not isinstance(document, dict):
        return None
    value = document.get('crs')
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        properties = value.get('properties', {})
        if value.get('type') == 'name' and 'name' in properties:
            return properties['name']
        if value.get('type', '').upper() == 'EPSG' and 'code' in properties:
            return f"EPSG:{properties['code']}"
        raise ValueError('Déclaration de CRS du polygone inconnue.')
    return None


def read_polygon(path):
    document = json.loads(path.read_text(encoding='utf-8'))
    crs = declared_crs(document)
    if isinstance(document, dict) and document.get('type') == 'FeatureCollection':
        if len(document['features']) != 1:
            raise ValueError('Le GeoJSON doit contenir un seul polygone.')
        document = document['features'][0]
        crs = declared_crs(document) or crs
    if isinstance(document, dict) and document.get('type') == 'Feature':
        document = document['geometry']
        crs = declared_crs(document) or crs
    if isinstance(document, dict) and document.get('type') == 'Polygon':
        document = document['coordinates'][0]
    if not isinstance(document, list):
        raise ValueError('Donner une liste de sommets ordonnés ou un Polygon GeoJSON.')
    points = [(float(point[0]), float(point[1])) for point in document]
    if points and points[0] == points[-1]:
        points.pop()
    if len(set(points)) < 3 or not all(math.isfinite(value) for point in points for value in point):
        raise ValueError('Le polygone doit avoir au moins trois sommets distincts et finis.')
    return points, crs


def previous_grid(directory):
    meta = json.loads((directory / 'terrain.json').read_text(encoding='utf-8'))
    return Grid(int(meta['crs'].removeprefix('EPSG:')), tuple(meta['topLeft']), tuple(meta['cellSize']),
                meta['columns'], meta['rows'])


def geographic_region(points):
    west, east = min(p[0] for p in points), max(p[0] for p in points)
    south, north = min(p[1] for p in points), max(p[1] for p in points)
    if -6.0 <= west <= east <= 10.0 and 41.0 <= south <= north <= 52.0:
        return 'ign'
    if -125.5 <= west <= east <= -66.0 and 24.0 <= south <= north <= 50.0:
        return 'usgs'
    return None


def metric_epsg(crs):
    epsg = crs.to_epsg()
    meters = all(abs(axis.unit_conversion_factor - 1) < 1e-12 for axis in crs.axis_info[:2])
    if not crs.is_projected or not meters or epsg is None:
        raise ValueError('Le CRS de grille doit être un EPSG projeté en mètres.')
    return epsg


def projection_for(input_crs, location, requested=None, previous=None):
    if previous and requested is None:
        return CRS.from_epsg(previous.epsg)
    if requested:
        return CRS.from_user_input(requested)
    if input_crs.is_projected:
        try:
            metric_epsg(input_crs)
        except ValueError:
            pass
        else:
            return input_crs
    if geographic_region(location) == 'ign':
        return CRS.from_epsg(2154)
    # Use the hull centre to select a local UTM CRS for geographic coordinates.
    longitude = sum(p[0] for p in location) / len(location)
    latitude = sum(p[1] for p in location) / len(location)
    if not (-80 < latitude < 84) or max(p[0] for p in location) - min(p[0] for p in location) > 180:
        raise ValueError('Préciser un CRS métrique avec --crs-grille pour ce polygone.')
    zone = max(1, min(60, int((longitude + 180) // 6) + 1))
    return CRS.from_epsg((32600 if latitude >= 0 else 32700) + zone)


def grid_for(points, epsg, spacing, margin, previous):
    x = [point[0] for point in points]
    y = [point[1] for point in points]
    # An anchored metric lattice makes old observation cells reusable on expansion.
    west, east = min(x) - margin, max(x) + margin
    south, north = min(y) - margin, max(y) + margin
    anchor_x, anchor_y = (0.0, 0.0)
    if previous:
        if previous.epsg != epsg or previous.spacing != spacing:
            raise ValueError('Pour étendre la grille, conserver le CRS et le pas du terrain précédent.')
        old_west, old_south, old_east, old_north = previous.bounds
        west, south = min(west, old_west), min(south, old_south)
        east, north = max(east, old_east), max(north, old_north)
        anchor_x, anchor_y = previous.origin
    dx, dy = spacing
    left = math.floor((west - anchor_x) / dx + 1e-9)
    right = math.ceil((east - anchor_x) / dx - 1e-9)
    bottom = math.floor((south - anchor_y) / dy + 1e-9)
    top = math.ceil((north - anchor_y) / dy - 1e-9)
    if left >= right or bottom >= top:
        raise ValueError('La grille doit couvrir une surface non nulle.')
    return Grid(epsg, (anchor_x + left * dx, anchor_y + top * dy), spacing, right - left, top - bottom)


def warp(dataset, grid):
    warped = gdal.Warp('', dataset, format='MEM', dstSRS=f'EPSG:{grid.epsg}', outputBounds=grid.bounds,
                       width=grid.columns, height=grid.rows, dstNodata=NO_DATA,
                       outputType=gdal.GDT_Float32, resampleAlg=gdal.GRA_Bilinear)
    return warped.GetRasterBand(1).ReadAsArray()


def request(url, params):
    req = Request(url + '?' + urlencode(params), headers={'User-Agent': 'Pharo-Roassal terrain preparation'})
    with urlopen(req, timeout=60) as response:
        data = response.read()
        if response.headers.get('Content-Encoding', '').lower() == 'gzip':
            data = gzip.decompress(data)
    return data


def ign_tile(grid):
    payload = request(IGN, {'SERVICE':'WMS', 'VERSION':'1.3.0', 'REQUEST':'GetMap',
                            'CRS':f'EPSG:{grid.epsg}', 'BBOX':','.join(map(str, grid.bounds)),
                            'WIDTH':grid.columns, 'HEIGHT':grid.rows,
                            'LAYERS':'ELEVATION.ELEVATIONGRIDCOVERAGE.HIGHRES',
                            'STYLES':'normal', 'FORMAT':'image/x-bil;bits=32'})
    if len(payload) != grid.rows * grid.columns * 4 or payload[:1] in (b'{', b'<'):
        raise ValueError('Réponse IGN inattendue. Essayer EPSG:2154 ou fournir un GeoTIFF avec --mnt.')
    height = np.frombuffer(payload, dtype='<f4').reshape(grid.rows, grid.columns).copy()
    height[np.isin(height, [-9999, -99999, -32768, -999999])] = NO_DATA
    return height


def usgs_tile(grid):
    payload = request(USGS, {'bbox':','.join(map(str, grid.bounds)), 'bboxSR':grid.epsg, 'imageSR':grid.epsg,
                             'size':f'{grid.columns},{grid.rows}', 'format':'tiff', 'pixelType':'F32',
                             'adjustAspectRatio':'false', 'f':'image'})
    virtual_file = f'/vsimem/{uuid4()}.tif'
    gdal.FileFromMemBuffer(virtual_file, payload)
    raster = None
    try:
        raster = gdal.Open(virtual_file)
        return warp(raster, grid)
    finally:
        raster = None
        gdal.Unlink(virtual_file)


def lookup(grid, source):
    fn = {'ign': ign_tile, 'usgs': usgs_tile}[source]
    result = np.empty((grid.rows, grid.columns), dtype=np.float32)
    for y in range(0, grid.rows, TILE_SIDE):
        for x in range(0, grid.columns, TILE_SIDE):
            tile = grid.tile(x, y)
            result[y:y + tile.rows, x:x + tile.columns] = fn(tile)
    return result


def write_csv(path, array, require_valid):
    array[~np.isfinite(array)] = NO_DATA
    if require_valid and not np.any(array != NO_DATA):
        raise ValueError('Le MNT ne contient aucune altitude valide dans cette emprise.')
    np.savetxt(path, array, fmt='%.4f', delimiter=',')


def prepare(args):
    points, polygon_crs = read_polygon(args.polygone)
    source_crs = CRS.from_user_input(args.crs_points or polygon_crs or 'EPSG:4326')
    if args.origine:
        metric_epsg(source_crs)
        ox, oy = args.origine
        sign = -1 if args.y_vers_le_bas else 1
        points = [(ox + x, oy + sign * y) for x, y in points]
    elif args.y_vers_le_bas:
        raise ValueError('--y-vers-le-bas exige une origine géoréférencée.')
    location = list(Transformer.from_crs(source_crs, 4326, always_xy=True).itransform(points, errcheck=True))
    if any(not (-180 <= x <= 180 and -90 <= y <= 90) for x, y in location):
        raise ValueError('Les sommets sont hors domaine. Vérifier leur repère et --crs-points.')
    previous = previous_grid(args.etendre) if args.etendre else None
    target = projection_for(source_crs, location, args.crs_grille, previous)
    projected = list(Transformer.from_crs(source_crs, target, always_xy=True).itransform(points, errcheck=True))
    step = args.pas if args.pas is not None else (previous.spacing[0] if previous else 20.0)
    step_y = args.pas_nord if args.pas_nord is not None else (
        previous.spacing[1] if previous and args.pas is None else step)
    if not all(math.isfinite(value) and value > 0 for value in (step, step_y)):
        raise ValueError('Le pas de grille doit être fini et positif.')
    if not math.isfinite(args.marge) or args.marge < 0:
        raise ValueError('La marge doit être finie et positive ou nulle.')
    grid = grid_for(projected, metric_epsg(target), (step, step_y), args.marge, previous)
    provider = 'geotiff' if args.mnt else (geographic_region(location) if args.source == 'auto' else args.source)
    if not provider:
        raise ValueError('Pas de fournisseur automatique pour cette zone. Fournir le MNT GeoTIFF avec --mnt.')
    if args.sortie.exists():
        raise ValueError('Choisir un nouveau dossier de sortie pour conserver le terrain existant.')
    args.sortie.parent.mkdir(parents=True, exist_ok=True)
    ground = warp(gdal.Open(str(args.mnt)), grid) if args.mnt else lookup(grid, provider)
    surface = warp(gdal.Open(str(args.mns)), grid) if args.mns else None
    metadata = {'version':1, 'crs':f'EPSG:{grid.epsg}', 'topLeft':list(grid.origin),
                'cellSize':list(grid.spacing), 'columns':grid.columns, 'rows':grid.rows,
                'noData':NO_DATA, 'ground':'mnt.csv', 'surface':'mns.csv' if args.mns else None,
                'polygonProjected':projected, 'source':provider, 'inputCrs':source_crs.to_string(),
                'inputOrigin':args.origine, 'inputYDown':args.y_vers_le_bas}
    with tempfile.TemporaryDirectory(prefix='.terrain-', dir=args.sortie.parent) as staging:
        root = Path(staging)
        write_csv(root / 'mnt.csv', ground, require_valid=True)
        if surface is not None:
            write_csv(root / 'mns.csv', surface, require_valid=True)
        (root / 'terrain.json').write_text(json.dumps(metadata, indent=2) + '\n', encoding='utf-8')
        root.rename(args.sortie)
    print(f'{grid.columns} colonnes × {grid.rows} lignes · EPSG:{grid.epsg} · {provider} · {args.sortie}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('polygone', type=Path)
    parser.add_argument('sortie', type=Path)
    parser.add_argument('--crs-points', help='remplacer le CRS déclaré, longitude/latitude par défaut')
    parser.add_argument('--crs-grille', help='CRS métrique du raster produit')
    parser.add_argument('--origine', type=float, nargs=2, metavar=('X', 'Y'), help='origine métrique des points XY locaux')
    parser.add_argument('--y-vers-le-bas', action='store_true', help='inverser Y pour des coordonnées écran')
    parser.add_argument('--pas', type=float, help='pas du raster en mètres, 20 m par défaut')
    parser.add_argument('--pas-nord', type=float, help='pas vertical du raster si différent')
    parser.add_argument('--marge', type=float, default=700, help='marge autour du polygone en mètres')
    parser.add_argument('--etendre', type=Path, help='dossier précédent dont la grille doit être prolongée')
    parser.add_argument('--source', choices=('auto','ign','usgs'), default='auto')
    parser.add_argument('--mnt', type=Path, help='GeoTIFF terrain déjà disponible')
    parser.add_argument('--mns', type=Path, help='GeoTIFF de surface optionnel, exprimé en altitudes')
    try:
        prepare(parser.parse_args())
    except (RuntimeError, ValueError, OSError, KeyError, IndexError, TypeError) as error:
        parser.exit(1, f'{error}\n')


if __name__ == '__main__':
    main()
